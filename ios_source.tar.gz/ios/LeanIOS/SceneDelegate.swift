//
//  SceneDelegate.swift
//  MedianIOS
//
//  Created by Kevin Mercado on 9/23/26.
//  Copyright © 2026 GoNative.io. All rights reserved.
//

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {

        guard let windowScene = scene as? UIWindowScene else {
            return
        }

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard.instantiateInitialViewController()

        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = rootVC
        self.window = window

        window.makeKeyAndVisible()
        if let appDelegate = UIApplication.shared.delegate as? NSObject {
            appDelegate.setValue(window, forKey: "window")
        }
    }
}
